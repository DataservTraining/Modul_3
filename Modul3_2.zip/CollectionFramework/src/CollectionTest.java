import java.util.*;
//import java.util.Iterator;
//import java.util.List;



public class CollectionTest {

	public static void main(String[] args) {
		Person p1 = new Person("Willi", "Wuff", 12);
		Person p2 = new Person("Donald", "Duck", 34);
		Person p3 = new Person("Daisy", "Duck", 23);
		Person p4 = new Person("Willibald", "Igel", 10);
		// 
		Set<Integer> integer = new TreeSet<>();
		boolean ok = integer.add(23);
		System.out.println(ok);
		ok = integer.add(34);
		System.out.println(ok);
		integer.add(2122);
		integer.add(67);
		ok = integer.add(34);
		System.out.println(ok);
//		ok = integer.add(null);
//		System.out.println(ok);
//		ok = integer.add(null);
//		System.out.println(ok);
		
//		for(int index = 0; index < integer.size(); ++index) {
//			System.out.print(integer.get(index) + ", ");
//		}
		
		System.out.println();
		Iterator<Integer> it = integer.iterator();
		
		while(it.hasNext()) {
			System.out.print(it.next() + ", ");
		}
		
		System.out.println();
		
		for(Integer i : integer) {
			System.out.print(i + ", ");
		}
		System.out.println();
		
		Set<Person> personen = new TreeSet<>(new Comparator<Person>() {

			@Override
			public int compare(Person o1, Person o2) {
				return o2.getAlter() - o1.getAlter();
			}
		});
		personen.add(p1);
		personen.add(p2);
		personen.add(p3);
		personen.add(p4);
		
		Set<Person> personenSortiert = new TreeSet<>(new Comparator<Person>() {

			@Override
			public int compare(Person o1, Person o2) {
				return o2.getNachname().compareTo(o1.getNachname());
			}
		});
		
		personenSortiert.addAll(personen);
		
		
		for(Person p : personen) {
			System.out.println(p);
		}
		System.out.println("=============================");
		for(Person p : personenSortiert) {
			System.out.println(p);
		}

	}

}
