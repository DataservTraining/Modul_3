package application;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import java.util.Scanner;

public class StartJDBC {

	public static void main(String[] args) {
		// Class.forName("org.apache.derby.jdbc.ClientDriver"); bis Java 4 notwendig
		try {
//			Connection con = DriverManager.getConnection("jdbc:derby:directory:/home/guido/MyDB;create=true");
			Properties props = new Properties();
			props.load(new FileReader("zugang.txt"));
//			Class.forName("org.apache.derby.jdbc.ClientDriver");
//			Connection con = DriverManager.getConnection("jdbc:derby:/home/guido/OCP");
			Connection con = DriverManager.getConnection("jdbc:mysql://192.168.72.251:3307/OCP?serverTimezone=UTC", 
														 props.getProperty("user"), 
														 props.getProperty("password"));
//			con = DriverManager.getConnection("jdbc:mysql://192.168.72.251:3307/OCP","user", "pw");
			Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
			PreparedStatement pstmt = con.prepareStatement("select AuthorId Kennung, FirstName  Vorname, LastName Nachname from Author",ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
			String sql = """  
					create table person (
						id integer primary key,
						vorname varchar(20),
						nachname varchar(20)
					)
					""";
			
			String insert1 = """
						insert into person values 
						(6, 'Donald', 'Duck')
					""";
			
			String insert2 = """
					insert into person values 
					(7, 'Donald', 'Duck')
				""";
			
			String query = """
						select * from person where vorname=' """;
			Scanner scanner = new Scanner(System.in);
			System.out.println("Suche:");
			String eingabe = scanner.nextLine();
//			pstmt.setString(1, eingabe); 
			
//			con.setAutoCommit(false);
//			int x = stmt.executeUpdate(insert1);
//			
//			if(x == 1)
//			x = stmt.executeUpdate(insert2);
//			
//			if(x != 1) 
//				con.rollback();
//			else 
//				con.commit();
//			con.setAutoCommit(true);
			DatabaseMetaData dbmd = con.getMetaData();
			
			
			
//			stmt.executeUpdate(insert);
//			ResultSet rs = stmt.executeQuery(query);
			ResultSet rs = pstmt.executeQuery();
			ResultSetMetaData rsmd = rs.getMetaData();
			int anzahlSpalten = rsmd.getColumnCount();
			
			for(int spalte = 1; spalte <= anzahlSpalten; ++spalte) {
				System.out.println(rsmd.getCatalogName(spalte));
				System.out.println(rsmd.getColumnClassName(spalte));
				System.out.println(rsmd.getColumnDisplaySize(spalte));
				System.out.println(rsmd.getColumnLabel(spalte));
				System.out.println(rsmd.getColumnName(spalte));
				System.out.println(rsmd.getColumnTypeName(spalte));
				
			}
			
			final int ID = 1;
			final int VORNAME = 2;
			final int NACHNAME = 3;
			while(rs.next()) {
				System.out.println(rs.getInt(ID) + "\t" + rs.getString(VORNAME) + "\t" + rs.getString(NACHNAME));
			}
			
			rs.last();
			int anzahlZeilen = rs.getRow();
			rs.beforeFirst();
			rs.absolute(5);
			rs.updateString(VORNAME, "Lauren");
			rs.cancelRowUpdates();
			rs.updateString(VORNAME, "Willi");
			rs.updateRow();
			rs.moveToInsertRow();
			rs.updateInt(ID, 1112);
			rs.updateString(VORNAME, "Willi");
			rs.updateString(NACHNAME, "Wuff");
			rs.insertRow();
			rs.moveToCurrentRow();
			
			rs.close();
			
			stmt.executeUpdate("delete from Author where AuthorId > 1110");
			stmt.executeUpdate("update Author set FirstName='Lauren' where AuthorId = 1004");
			
			stmt.close();
			pstmt.close();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
