import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

class MyRunnable implements Runnable{
	private String name;
	
	
	
	public MyRunnable(String name) {
		super();
		this.name = name;
	}



	@Override
	public void run() {
		for(int i = 0; i < 5; ++i) {
			System.out.println(Thread.currentThread().getName() + ": " + name);
			try {
				Thread.sleep(15);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
	}
}

class MyRunnable2 implements Runnable{
	private String name;
	
	
	
	public MyRunnable2(String name) {
		super();
		this.name = name;
	}



	@Override
	public void run() {

			System.out.println(Thread.currentThread().getName() + ": " + name);
			try {
				Thread.sleep(15);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		
	}
}


public class Start {

	public static void main(String[] args) {
		
		ScheduledExecutorService service = Executors.newScheduledThreadPool(3);
//		service.submit(new MyRunnable("Runnable 1"));
//		service.submit(new MyRunnable("Runnable 2"));
//		service.submit(new MyRunnable("Runnable 3"));
//		service.submit(new MyRunnable("Runnable 4"));
//		service.submit(new MyRunnable("Runnable 5"));
		
//		service.schedule(new MyRunnable2("Runnable 1"), 1, TimeUnit.SECONDS);
//		service.schedule(new MyRunnable2("Runnable 2"), 50, TimeUnit.MILLISECONDS);
//		service.schedule(new MyRunnable2("Runnable 3"), 3, TimeUnit.SECONDS);
		service.scheduleAtFixedRate(new MyRunnable2("Runnable 4"), 1000, 3000, TimeUnit.MILLISECONDS);
		service.scheduleAtFixedRate(new MyRunnable2("Runnable 1"), 1000, 1000, TimeUnit.MILLISECONDS);
//		service.shutdown();
	}

}
