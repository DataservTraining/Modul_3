import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public class CallableTest {

	private static Callable<Integer> task = new Callable<Integer>() {

		@Override
		public Integer call() throws Exception {
				int summe = 0;
				for(int z = 1; z < 101; ++z) {
					summe += z;
					try {
						Thread.sleep(50);
					} catch (InterruptedException e) {
			
					}
				}
				return summe;
		}
		
	};
	
	public static void main(String[] args) {
		ExecutorService service = Executors.newSingleThreadExecutor();
		
		Future<Integer> result = service.submit(task);
		
		System.out.println("in Main()");
		try {
			while(!result.isDone()) {
				System.out.println("irgendetwas anderes machen");
			}
			System.out.println(result.get());
		
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (ExecutionException e) {
			e.printStackTrace();
		} 
		service.shutdown();
	}

}
