import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class InputOutputTest {

	public static void main(String[] args) {
		try {
			DataOutputStream out = new DataOutputStream(new FileOutputStream("daten.dat"));
			out.writeUTF("Hallo Welt");
			out.writeDouble(34.56);
			out.writeBoolean(true);
			out.close();
			
			DataInputStream in = new DataInputStream(new FileInputStream("daten.dat"));
			String text = in.readUTF();
			double d = in.readDouble();
			boolean ok = in.readBoolean();
			
			in.close();
			System.out.println(text);
			System.out.println(d);
			System.out.println(ok);
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
