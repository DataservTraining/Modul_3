import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

class MyAutoClosable implements AutoCloseable{

	@Override
	public void close() throws IOException {
		System.out.println("close() von MyAutoclosable");
		throw new IOException("von close() in MyAutoclosable");
	}
	
}

public class ReaderWriterTest {

	public static void main(String[] args) {
		try (MyAutoClosable myAutoClosable = new MyAutoClosable()) {
//			FileWriter out = new FileWriter("text.txt", false);
			PrintWriter out = new PrintWriter(new FileWriter("text.txt", false));
			out.println("Hallo Welt");
			out.println(23.56);
			out.close();
			
			BufferedReader in = new BufferedReader(new FileReader("text.txt"));
//			char[] buffer = new char[1024];
//			int anzahl = in.read(buffer);
			String zeile;
			while((zeile = in.readLine()) != null)
				System.out.println(zeile);
			in.close();
//			String text = new String(buffer, 0, anzahl);
//			System.out.println(text);
			
		} catch (IOException e) {
			System.out.println("in catch-Block");
			e.printStackTrace();
		} finally {
			System.out.println("finally-Block");
		}

	}

}
