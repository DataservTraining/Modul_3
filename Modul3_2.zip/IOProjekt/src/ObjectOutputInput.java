import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class ObjectOutputInput {

	public static void main(String[] args) {
		Person p1 = new Person("Willi", "Wuff", 12, "Musterweg", 10, "München");
		Person p2 = new Person("Donald", "Duck", 34, "Musterweg", 20, "München");
		Person p3 = new Person("Daisy", "Duck", 23, "Musterweg", 30, "München");
		Person p4 = new Person("Willibald", "Igel", 10, "Musterweg", 40, "München");
		
		try {
//			ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("personen.dat"));
//			out.writeObject(p1);
//			out.writeObject(p2);
//			out.writeObject(p3);
//			out.writeObject(p4);
//			out.close();
			
			ObjectInputStream in = new ObjectInputStream(new FileInputStream("personen.dat"));
			Person p11 = (Person) in.readObject();
			Person p12 = (Person) in.readObject();
			Person p13 = (Person) in.readObject();
			Person p14 = (Person) in.readObject();
			
			in.close();
			
			System.out.println(p11);
			System.out.println(p12);
			System.out.println(p13);
			System.out.println(p14);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

}
