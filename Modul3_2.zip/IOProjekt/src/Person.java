
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Objects;

class Lebewesen {

	public Lebewesen() {

	}

	public Lebewesen(int x) {

	}
}

class Adresse{
	private String strasse;
	private String ort;
	private int hausnummer;
	
	public Adresse() {
		super();
	}
	public Adresse(String strasse, String ort, int hausnummer) {
		super();
		this.strasse = strasse;
		this.ort = ort;
		this.hausnummer = hausnummer;
	}
	public String getStrasse() {
		return strasse;
	}
	public void setStrasse(String strasse) {
		this.strasse = strasse;
	}
	public String getOrt() {
		return ort;
	}
	public void setOrt(String ort) {
		this.ort = ort;
	}
	public int getHausnummer() {
		return hausnummer;
	}
	public void setHausnummer(int hausnummer) {
		this.hausnummer = hausnummer;
	}
	@Override
	public String toString() {
		return "Adresse [strasse=" + strasse + ", ort=" + ort + ", hausnummer=" + hausnummer + "]";
	}
	
	
}

public class Person extends Lebewesen implements Comparable<Person>, Serializable {
	private static final long serialVersionUID = 3L;
	private String vorname = "";
	private String nachname = "";
	private int alter = 1;
	private transient Adresse adresse;

	{
		alter = 5;
	}

	public Person() {
		super(3);
	}

	public Person(String vorname, String nachname, int alter, String strasse, int hausnummer, String ort) {
		super(2);
		this.vorname = vorname;
		this.nachname = nachname;
		this.alter = alter;
		adresse = new Adresse(strasse, ort, hausnummer);
	}

	public String getVorname() {
		return vorname;
	}

	public void setVorname(String vorname) {
		this.vorname = vorname;
	}

	public String getNachname() {
		return nachname;
	}

	public void setNachname(String nachname) {
		this.nachname = nachname;
	}

	public int getAlter() {
		return alter;
	}

	public void setAlter(int alter) {
		this.alter = alter;
	}

	@Override
	public int hashCode() {
		return Objects.hash(nachname);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Person other = (Person) obj;
		return Objects.equals(nachname, other.nachname);
	}

	

	@Override
	public String toString() {
		return "Person [vorname=" + vorname + ", nachname=" + nachname + ", alter=" + alter + ", adresse=" + adresse
				+ "]";
	}

	@Override
	public int compareTo(Person o) {
//		Rückgabewert:
//		 < 0 wenn this vor o
//		 = 0 wenn this an gleicher Stelle wie o steht
//		 > 0 wenn o vor this
		if (this.vorname.equals(o.vorname)) {
			if (this.nachname.equals(o.nachname)) {
				return this.alter - o.alter;
			} else {
				return this.nachname.compareTo(o.nachname);
			}

		} else {
			return this.vorname.compareTo(o.vorname);
		}

	}
	
	private void writeObject(ObjectOutputStream out) {
		try {
			out.defaultWriteObject();
			out.writeUTF(adresse.getStrasse());
			out.writeUTF(adresse.getOrt());
			out.writeInt(adresse.getHausnummer());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private void readObject(ObjectInputStream in) {
		try {
			in.defaultReadObject();
			adresse = new Adresse(in.readUTF(), in.readUTF(), in.readInt());
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
