package application;

import java.util.ArrayList;
import java.util.List;

public class Start {

	public static void main(String[] args) {
		MyArrayList<String> liste = new MyArrayList<>();
		liste.add("");
		liste.add("");
		String text = liste.get(0);
		MyArrayList<Integer> integer = new MyArrayList<>();
		integer.add(23);
		
		List<Animal> animals = new ArrayList<Animal>();
		List<Dog> dogs = new ArrayList<Dog>();
		List<Cat> cats = new ArrayList<Cat>();
		
		Animal animal1 = new Animal(); Animal animal2 = new Animal(); Animal animal3 = new Animal();
		Dog dog1 = new Dog(); Dog dog2 = new Dog(); Dog dog3 = new Dog();
		Cat cat1 = new Cat(); Cat cat2 = new Cat(); Cat cat3 = new Cat();
		
		animals.add(animal1);
		animals.add(cat3);
		animals.add(dog2);
		dogs.add(dog3);
		dogs.add(dog1);
		dogs.add(dog2);
		
		cats.add(cat1);
		cats.add(cat2);
		cats.add(cat3);
		
		impfen(animals);
		impfen(dogs);
		impfen(cats);
		
		vermehren(animals);
//		vermehren(dogs);
		
		List<Object> objekte = new ArrayList<Object>();
		
		vermehren(objekte);

	}
	
	
	public static void impfen(List<? extends Animal> liste) {
		//liste.add(new Cat());
		for(var a : liste) {
			a.geimpft();
		}
	}
	
	public static void vermehren(List<? super Animal> liste) {
		liste.add(new Animal());
		liste.add(new Dog());
		liste.add(new Cat());
//		liste.add(new Person());
	}
	

	
	
	
	
	public static void test(int x) {}
	public static void test(double x) {}
	public static void test(List<String> x) {}
//	public static void test(List<Integer> x) {}
	
//	public static void test(List x) {}
//	public static void test(List x) {}


}
