package application;

public class Cat extends Animal {

}
