package client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class ChatClient {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		try {
			Socket socket = new Socket("localhost", 12345);
			BufferedReader reader = new BufferedReader(
					new InputStreamReader(socket.getInputStream()));
			PrintWriter writer = new PrintWriter(
					new OutputStreamWriter(socket.getOutputStream()));
			
			Thread readerThread = new Thread(new Runnable() {
				
				@Override
				public void run() {
					while(true) {
						String antwort;
						try {
							antwort = reader.readLine();
							System.out.println(antwort);
						} catch (IOException e) {
							System.out.println(e.getMessage());
							return;
						}
					}
					
				}
			});
			
			readerThread.setDaemon(true);
			readerThread.start();
			
			
			System.out.println("Bitte geben Sie Ihren Namen ein:");
			String name = scanner.nextLine();
			writer.println(name);
			writer.flush();
			
			String message = "";
			
			do {
//				System.out.println("Bitte Nachricht eingeben: ");
				message = scanner.nextLine();
				writer.println(message);
				writer.flush();
				
			}while(!message.equals("____ENDE____"));
			
			System.out.println("Client beendet");
			socket.close();
			
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		

		scanner.close();

	}

}
