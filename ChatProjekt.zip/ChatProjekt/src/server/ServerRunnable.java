package server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.List;
import java.util.Vector;

public class ServerRunnable implements Runnable{
	
	private ServerSocket serverSocket;
	private List<ClientThread> clients;
	private boolean serverIsRunning = true;
	

	public ServerRunnable() {
		super();
		try {
			serverSocket = new ServerSocket(12345);
			clients = new Vector<>();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}



	@Override
	public void run() {
		System.out.println("Server gestartet");
		while(serverIsRunning) {
			Socket socket;
			try {
				socket = serverSocket.accept();
				ClientThread clientThread = new ClientThread(this, socket);
				new Thread(clientThread).start();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
	}
	
	public void serverStoppen() {
		serverIsRunning = false;
		verteileMessage("Server: ", " wird heruntergefahren");
		for(ClientThread client : clients) {
				client.stopClient();
		}
		clients.clear();
	}
	
	public void abmelden(ClientThread client) {
		client.stopClient();
		clients.remove(client);
		verteileMessage(client.getName(), " hat sich abgemeldet");
	}
	
	public void anmelden(ClientThread clientThread) {
		clients.add(clientThread);
		verteileMessage(clientThread.getName(), " hat sich angemeldet");
		
	}

	public void verteileMessage(String name, String message) {
		System.out.println(name + ": " + message);
		for(ClientThread client : clients) {
			client.sendMessage(name + ": " + message);
		}
	}




}
