package server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;

public class ClientThread implements Runnable {
	private String name;
	private BufferedReader reader;
	private PrintWriter writer;
	private ServerRunnable server;
	private Socket socket;
	private boolean running = true;
	private boolean start = true;

	public ClientThread(ServerRunnable serverRunnable, Socket socket) {
		this.server = serverRunnable;
		this.socket = socket;
		try {
			reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			writer = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()));
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	@Override
	public void run() {
		while (running) {
			String message = "";

			try {

				message = reader.readLine();

				if (start) {
					name = message;
					server.anmelden(this);
					
					start = false;
				} else {
					
					if (message.equals("____ENDE____")) {
						server.abmelden(this);
					} else {
						server.verteileMessage(this.name, message);
					}
				}
			} catch (IOException e) {
				e.printStackTrace();
				stopClient();
			}

		}

	}

	public void sendMessage(String message) {
		writer.println(message);
		writer.flush();
	}

	public String getName() {
		return name;
	}

	public Socket getSocket() {
		return socket;

	}

	public void stopClient() {
		try {
			socket.close();
		} catch (IOException e) {
			System.out.println("Fehler: " + e.getMessage());
		}
		running = false;
	}

}
