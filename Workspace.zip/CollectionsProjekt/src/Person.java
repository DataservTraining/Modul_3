import java.util.Objects;

public class Person implements Comparable<Person>{
	private String name;
	private int alter;
	private double gehalt;
	private String email;
	
	
	public Person(String name, int alter, double gehalt) {
		super();
		this.name = name;
		this.alter = alter;
		this.gehalt = gehalt;
		this.email = name.replace(" ", "-") + "@t-online.de";
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getAlter() {
		return alter;
	}


	public void setAlter(int alter) {
		this.alter = alter;
	}


	public double getGehalt() {
		return gehalt;
	}


	public void setGehalt(double gehalt) {
		this.gehalt = gehalt;
	}


	


	@Override
	public String toString() {
		return "Person [name=" + name + ", alter=" + alter + ", gehalt=" + gehalt + ", email=" + email + "]";
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	@Override
	public int compareTo(Person o) {
		System.out.println("compareTo");
		// R�ckgabewerte:
		// -1 bedeutet: this vor o in der Sortierung
		// 0 bedeutet: this und o an der gleichen Stelle in der Sortierung
		// 1 bedeutet: o vor this in der Sortierung
		return this.name.compareTo(o.name);
	}


	@Override
	public int hashCode() {
		return Objects.hash(alter, gehalt, name);
	}


	@Override
	public boolean equals(Object obj) {
		System.out.println("equals");
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Person other = (Person) obj;
		return alter == other.alter && Double.doubleToLongBits(gehalt) == Double.doubleToLongBits(other.gehalt)
				&& Objects.equals(name, other.name);
	}
	
	
	

}
