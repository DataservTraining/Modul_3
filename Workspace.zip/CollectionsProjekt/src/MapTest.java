import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class MapTest {

	public static void main(String[] args) {
		List<Person> personen = Utils.createPersonenGeordnet(5);
//		personen.sort(null);
		System.out.println(personen);
		Map<String, Person> personenMap = new LinkedHashMap<>(30, 0.75F, true);
		
		for(Person person : personen) {
			Person rueckgabeWert = personenMap.put(person.getEmail(), person);
//			System.out.println(rueckgabeWert);
		}
		
		
//		for(String key : personenMap.keySet()) {
//			System.out.println("Key: " + key + " \t" + personenMap.get(key));
//		}
		for (var entry : personenMap.entrySet()){
			System.out.println("Key: " + entry.getKey() + " \t" + entry.getValue());
		}
		
		System.out.println(personenMap.get("Name-3@t-online.de"));
		
		
		System.out.println("\n======================================\n");
		
		for(Map.Entry<String, Person> entry : personenMap.entrySet()) {
			System.out.println("Key: " + entry.getKey() + " \t" + entry.getValue());
		}
		
		System.out.println(personenMap.get("Name-1@t-online.de"));
		
		System.out.println("\n======================================\n");
		for (var entry : personenMap.entrySet()){
			System.out.println("Key: " + entry.getKey() + " \t" + entry.getValue());
		}
		System.out.println("\n======================================\n");
	}
	
	

}
