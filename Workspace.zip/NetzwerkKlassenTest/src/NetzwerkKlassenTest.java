import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;

public class NetzwerkKlassenTest {

	public static void main(String[] args) {
		try {
			URL url = new URL("http://www.tutego.com:80/index.html");
			System.out.println("url.getDefaultPort(): " + url.getDefaultPort());
			System.out.println("url.getPort(): " + url.getPort());
			System.out.println("url.getHost(): " + url.getHost());
			System.out.println("url.getContent(): " + url.getContent());
			InputStream in = url.openStream();
			byte[] buffer = new byte[1024];
			int len = 0;
			while((len = in.read(buffer)) != -1) {
				System.out.write(buffer, 0, len);
			}
			
			InetAddress address = InetAddress.getByAddress(new byte[] {(byte)192, (byte) 168, 72, (byte) 231});
			System.out.println();
			System.out.println(address);
			System.out.println(InetAddress.getLocalHost());
			System.out.println(address.getHostName());
			System.out.println(address.getHostAddress());
			System.out.println(InetAddress.getByName("10.0.2.15").isReachable(2000));
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
