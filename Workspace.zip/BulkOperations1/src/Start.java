import java.util.List;
import java.util.function.Predicate;

public class Start {

	public static void main(String[] args) {
		final Predicate<String> isNull = str -> str == null;
		final Predicate<String> isEmpty = str -> str.isEmpty();
		final Predicate<Person> isAdult = p -> p.getAge() >= 18;
		final Predicate<Person> isMale = p -> p.getGender() == Gender.MALE;
		final Predicate<Person> isYoung = isAdult.negate();
		final Predicate<Person> isFemale = isMale.negate();
		final Predicate<Person> boys = isMale.and(isYoung);
		final Predicate<Person> women = isFemale.and(isAdult);
		final Predicate<Person> boysOrWomen = boys.or(women);
		final Predicate<Person> boysAndGirls = boys.or(isFemale.and(isYoung));

		
		System.out.println("isNull: " + isNull.test(""));
		System.out.println("isNull: " + isNull.test(null));
		System.out.println("isNull: " + isEmpty.test(""));
		System.out.println("isNull: " + isEmpty.test("Pia"));
		System.out.println("isAdult: " + isAdult.test(new Person("Pia", 55)));
		
		List<Person> personen = DemoData.createDemoData();
		personen.forEach(System.out::println);
		System.out.println("\n=====================================\n");
		DemoData.removeAll(personen, isAdult);
		personen.forEach(System.out::println);
		
		List<String> namen = DemoData.createDemoNames();
		namen.forEach(System.out::println);
		namen.removeIf(str -> str.trim().isEmpty());
		namen.forEach(System.out::println);
		

	}

}
