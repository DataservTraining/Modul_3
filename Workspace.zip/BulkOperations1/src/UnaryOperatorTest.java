import java.util.List;
import java.util.function.UnaryOperator;

public class UnaryOperatorTest {

	public static void main(String[] args) {
		final UnaryOperator<String> marksTextWithM = str -> 
									str.startsWith("M") ? ">>" + str.toUpperCase() + "<<" : str;
									
		final UnaryOperator<String> mapNullToEmpty = str -> str == null ? "" : str;
		
	    DemoData.printResult("Mark 1", "unchanched", marksTextWithM);
	    DemoData.printResult("Mark 2", "Michael", marksTextWithM);

	    
	    DemoData.printResult("Map same", "same", mapNullToEmpty);
	    DemoData.printResult("Map same", null, mapNullToEmpty);
	    
	    List<String> namen = DemoData.createDemoNames();
	    
	    namen.forEach(str -> System.out.print(str + ", "));
	    System.out.println();
	    namen.replaceAll(mapNullToEmpty);
	    namen.forEach(str -> System.out.print(str + ", "));
	    namen.replaceAll(String::trim);
	    System.out.println();
	    namen.forEach(str -> System.out.print(str + ", "));
	    namen.removeIf(String::isEmpty);
	    System.out.println();
	    namen.forEach(str -> System.out.print(str + ", "));
	    
	}

}
