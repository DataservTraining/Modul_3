import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class Start2 {

	public static void main(String[] args) {
		final List<String> names = Arrays.asList("Mike", "Stefan", "Nikolaos");
		Stream<String> values = names.stream()
									 .mapToInt(String::length) // mapToInt(str -> str.length())
									 .asLongStream()
									 .boxed()
									 .mapToDouble(v -> v * 0.75)
									 .mapToObj(v -> "Wert: " + v);
		values.forEach(str -> System.out.print(str + ", "));
		System.out.println();
		
		List<Person> personen = DemoData.createPersonsListWithCities();
		System.out.println(personen);
		Stream<Person> adults = personen.stream().filter(Person::isAdult);
		adults.forEach(System.out::println);
		
		Stream<Person> allAdultMikes = personen.stream()
											.filter(Person::isAdult)
											.filter(p-> p.getName().equals("Micha"))
											.filter(p -> p.livesIn("Z�rich"));
		System.out.println();
		allAdultMikes.forEach(System.out::println);
		
		Stream<String> namen = personen.parallelStream()
				                       .filter(p -> p.livesIn("Z�rich")||p.livesIn("Hamburg"))
				                       .map(p -> p.getName()).sorted();
		
		namen.forEach(str -> System.out.print(str + ", "));
		
		System.out.println();
		personen.stream().map(p -> p.getAge()).sorted().forEach(str -> System.out.print(str + ", "));
		System.out.println();
		personen.stream().map(p->p.getName()).distinct().forEach(str -> System.out.print(str + ", "));
		
	}

}
