import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class LambdaTestRunnable {

	public static void main(String[] args) throws InterruptedException {
//		Thread uhr1 = 
		
		
		new Thread(()->{
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss.SS");
			
			while (true) {
				System.out.println(Thread.currentThread().getName() + ": " + formatter.format(LocalTime.now()));
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					return;
				}
			}
		}).start();

		
//		uhr1.setDaemon(true);
//		uhr1.start();
		Thread.sleep(3000);

	}

}
