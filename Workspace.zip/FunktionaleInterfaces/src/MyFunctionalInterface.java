

@FunctionalInterface
public interface MyFunctionalInterface {
	
	public abstract int add(int a, int b);
	
	public default double test() {
		System.out.println("ich bin default");
		return 0.0;
	}
	
	public static void xyz() {
		System.out.println("ich bin static");
	}

}
