
public interface A {
	
	void xyz();
	
	
	public default double test() {
		System.out.println("ich bin default in A");
		return 0.0;
	}
}
