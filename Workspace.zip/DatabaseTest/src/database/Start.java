package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Start {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		CoronaDBInterface db = DBFactory.getInstance();
		System.out.println(DBFactory.getDriver());
		Class.forName(DBFactory.getDriver());
		Connection con = DriverManager.getConnection(DBFactory.getURL() + DBFactory.getDatabase(), "guido",
				"Bagira");
		System.out.println(con);

	}

}
