package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Start {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		CoronaDBInterface db = DBFactory.getInstance();
		System.out.println(DBFactory.getDriver());
		Class.forName(DBFactory.getDriver());
		Connection con = DriverManager.getConnection(DBFactory.getURL() + DBFactory.getDatabase(), "Dozent",
				"dozent");
		Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
//		stmt.execute("create table SeminarDozent.test (id integer primary key, name varchar(10));");
		stmt.execute("drop table SeminarDozent.test");
		System.out.println(con);

	}

}
