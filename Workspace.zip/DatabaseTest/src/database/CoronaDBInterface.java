package database;

public interface CoronaDBInterface {

	

}
