package application;

public class Reader implements Runnable {
	private IntArray array;

	public Reader(IntArray array) {
		super();
		this.array = array;
	}

	@Override
	public void run() {
		int zahl = 0;
		while (zahl != -1) {
				zahl = array.read();
				if(zahl != -1) System.out.println(zahl + " gelesen");
			try {
				Thread.sleep(15);
			} catch (InterruptedException e) {
			}
		}

	}

}
