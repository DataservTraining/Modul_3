package application;

public class Start {

	public static void main(String[] args) {
		
		Thread uhrenThread = new Thread(new Uhr1());
		uhrenThread.start();
		
		IntArray array = new IntArray();
		
		Writer writer = new Writer(array);
		Reader reader = new Reader(array);
		Thread writerThread = new Thread(writer);
		Thread readerThread = new Thread(reader);
		writerThread.start();
		readerThread.start();

	}

}
