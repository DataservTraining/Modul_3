package application;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class Uhr1 implements Runnable{
	private boolean running = true;

	@Override
	public void run() {

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss.SS");
		
		while (running) {
			System.out.println(Thread.currentThread().getName() + ": " + formatter.format(LocalTime.now()));
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				return;
			}
		}
		
	}


	public boolean isRunning() {
		return running;
	}

	public void stoppRunning() {
		this.running = false;
	}
	
	
}
