package application;

public class StartCowboyJim {

	public static void main(String[] args) {
		KauThread kauen = new KauThread();
		LaufThread laufen = new LaufThread();
		kauen.setDaemon(true);
		laufen.setDaemon(true);
		kauen.start();
		laufen.start();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}


	}

}
