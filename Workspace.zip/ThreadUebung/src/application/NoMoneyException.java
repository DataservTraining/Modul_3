package application;

public class NoMoneyException extends Exception{

	public NoMoneyException(String arg0) {
		super(arg0);
	}
	
}
