package application;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Start {

	public static void main(String[] args) {
		ExecutorService service = Executors.newFixedThreadPool(2);
		
		for(int zaehler = 1; zaehler < 15; ++zaehler) {
			final int z = zaehler;
			service.execute(new Runnable() {
				
				@Override
				public void run() {
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
					}
					System.out.println(z + ". Task");
					
				}
			});
		}
		
		
		service.shutdown();

	}

}
