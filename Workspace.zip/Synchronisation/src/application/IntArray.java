package application;

public class IntArray {
	int[] feld = new int[5];
//	private Object monitor = new Object();
//	private Object monitor2 = new Object();
	int index = 0;
	
	public synchronized void write(int wert) {
		while(index == feld.length) {
			try {
				this.wait();
			} catch (InterruptedException e) {
			}
		}
		feld[index] = wert;
		++index;
		if(index == 1) {
			this.notifyAll();
		}
	}
	
	public synchronized int read() {
		while(index == 0) {
			try {
				this.wait();
			} catch (InterruptedException e) {
			}
		}
		int temp = feld[0];
		for(int i = 0; i < index-1; ++i) {
			feld[i] = feld[i+1];
		}
		--index;
		if(index == feld.length) {
			this.notifyAll();
		}
		return temp;
	}

	
//	public void write(int wert) {
//		System.out.println("vor synchonized-Block in write()");
//		synchronized (monitor) {
//			monitor.wait()
//			feld[index] = wert;
//			++index;
//		}
//		System.out.println("nach synchonized-Block in write()");
//	}
//	
//	public int read() {
//		synchronized (monitor) {
//			int temp = feld[0];
//			for(int i = 0; i < index-1; ++i) {
//				feld[i] = feld[i+1];
//			}
//			--index;
//			return temp;
//		}
//		
//	}
//	
//	public void a() {
//		synchronized (monitor2) {
//			
//		}
//	}
//	
//	
//	public void b() {
//		synchronized (monitor2) {
//			
//		}
//	}
//	
//	

}
