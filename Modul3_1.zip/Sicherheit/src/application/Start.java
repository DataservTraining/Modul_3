package application;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Start {

	public static void main(String[] args) {
		
		try {
			PrintWriter out = new PrintWriter(new FileWriter("text.txt"));
			out.println("Hallo Welt");
			out.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
