package application;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.OptionalDouble;
import java.util.Vector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class TerminateOperations {

	public static void main(String[] args) {
		List<Person> personen = DemoData.createDemoData();

		List<Person> personenGefiltert = personen.stream().filter(p -> p.getAge() > 10)
				.collect(Collectors.toCollection(Vector::new));

		System.out.println(personenGefiltert.getClass());

		personenGefiltert.forEach(System.out::println);

		String pers = personen.stream().filter(Person::isAdult).map(p -> p.getName()).sorted()
				.collect(Collectors.joining(", ", "Folgende Personen sind erwachsen: ", "!"));

		System.out.println(pers);

		long anzahl = personen.stream().filter(Person::isAdult).map(p -> p.getName()).sorted().count();

		System.out.println("Es sind " + anzahl + " Erwachsene");

		OptionalDouble avg = personen.stream().filter(Person::isAdult).mapToInt(p -> p.getAge()).average();

		System.out.println(
				"Das Durchschnittsalter ist: " + (avg.isPresent() ? avg.getAsDouble() : " lässt sich nich ermitteln"));

		System.out.println(personen.stream().filter(Person::isAdult).mapToInt(p -> p.getAge()).max().orElse(0));
		
		Stream<Person> pers2 = personen.stream()
										.filter(p -> p.getName().startsWith("M"));
		
		System.out.println(pers2.findAny().orElseThrow(IllegalArgumentException::new));
		System.out.println("********************************************************\n");
		
		final List<String> names = Arrays.asList("Stefan", "Ralph", "Andi", "Mike", "Florian", "Michael", "Sebastian");
				final String joined = names.stream().sorted().collect(Collectors.joining(", "));
				System.out.println(joined);
				
				Map<Integer, List<String>> grouped = names.stream()
														  .collect(Collectors.groupingBy(String::length));
				System.out.println(grouped);
				
				Map<Integer, Long> counting = names.stream()
											       .collect(Collectors.groupingBy(String::length, Collectors.counting()));
				System.out.println(counting);
				
				Map<Boolean, List<String>> partitions = names.stream()
															.filter(str -> str.contains("i"))
															.collect(Collectors.partitioningBy(str -> str.length() > 4));
				System.out.println(partitions);
		
	}

}
