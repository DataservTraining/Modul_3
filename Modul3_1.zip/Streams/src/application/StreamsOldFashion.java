package application;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamsOldFashion {

	public static void main(String[] args) {
		List<Person> personen = DemoData.createDemoData();
		List<Person> frauen = new ArrayList<>();
		
		for(var p : personen) {
			if(p.getGender() == Gender.FEMALE) {
				frauen.add(p);
			}
			
		}
		
		for(var p : frauen) {
			System.out.println(p);
		}
		
		System.out.println("===========================");
		
		List<Person> frauen2 = personen.stream()
				.filter(p -> p.getGender() == Gender.FEMALE)
				.collect(Collectors.toList());
		
		frauen2.forEach(System.out::println);
		System.out.println("===========================");
		Stream<Person> pStream = personen.stream()
										 .filter(p -> p.getGender() == Gender.FEMALE)
										 .filter(p -> p.getAge() > 20);
		
		pStream.forEach(System.out::println);

		

	}

}
