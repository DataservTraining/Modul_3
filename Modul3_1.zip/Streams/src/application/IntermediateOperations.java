package application;

import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;

public class IntermediateOperations {

	public static void main(String[] args) {
		List<Person> personen = DemoData.createDemoData();
		Predicate<Person> female = p -> p.getGender() == Gender.FEMALE;
		Predicate<Person> adult = p -> p.getAge() > 18;
		Predicate<Person> femaleAndAdult = female.and(adult);
		Predicate<Person> boys = femaleAndAdult.negate();
		Consumer<Person> printer = s -> System.out.println("Peek 1: " + s );
		Consumer<Person> printer2 = s -> System.out.println("\nPeek 2: " + s + "\n" );
		
		personen.forEach(System.out::println);
		
		System.out.println("==========================");
		
		personen.stream()
				.peek(printer)
				.filter(female.negate().and(adult.negate()))
				.peek(printer2)
				.sorted((p1, p2) -> p1.getAge() - p2.getAge())
				.forEach(System.out::println);
		
		
//		personen.stream()
				

	}

}
