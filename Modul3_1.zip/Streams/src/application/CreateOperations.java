package application;

import java.util.Arrays;
import java.util.List;
import java.util.stream.IntStream;
import java.util.stream.LongStream;
import java.util.stream.Stream;

public class CreateOperations {

	public static void main(String[] args) {
		final String[] namesData = { "Karl", "Ralph", "Andi", "Andy", "Mike" };
		final List<String> names1 = Arrays.asList(namesData);
		final Stream<String> names2 = Arrays.asList(namesData).stream();
		final Stream<String> streamFromArray = Arrays.stream(namesData);
		final Stream<String> streamFromList = names1.stream();
		
		IntStream integers = IntStream.range(1, 10);
		integers.forEach(System.out::println);
		System.out.println("==============================");
		integers = IntStream.rangeClosed(1, 10);
		integers.forEach(System.out::println);

		final List<String> names = Arrays.asList("Mike", "Stefan", "Nikolaos");
		Stream<String> values = names.stream().			//-> Stream<String>
				mapToInt(String::length).				//-> IntStream
				asLongStream().							//-> LongStream
				boxed().  								//-> Stream<Long>
				mapToDouble(x -> x * .75).  			//-> DoubleStream
				mapToObj(val -> "Val: " + val); 		//-> Stream<String>
				
		values.forEach(System.out::println);
		
		LongStream iteratingValues = LongStream.iterate(1, x -> x + 1)
											 .peek(e -> System.out.println("Peek: " + e))
											 .skip(10)
											 .limit(100)
											;
		
		iteratingValues.forEach(System.out::println);
		
	}

}
