package test;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

import entities.Person;

public class Server {

	public static void main(String[] args) {
		try {
			ServerSocket serverSocket = new ServerSocket(33333);
			System.out.println("Server gestartet");
			Socket server = serverSocket.accept();
			System.out.println("Verbindung hergestellt");
			ObjectOutputStream out = new ObjectOutputStream(server.getOutputStream());
			ObjectInputStream in = new ObjectInputStream(server.getInputStream());
			Person client = (Person) in.readObject();
			
			System.out.println(client.getVorname() + " " + client.getNachname() +  " hat sich angemeldet");
			out.writeUTF("Hallo " + client.getVorname());
			out.flush();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

}
