package test;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

import entities.Person;

public class Client {

	public static void main(String[] args) {
		try {
			Socket socket = new Socket("localhost", 33333);
			Person ich = new Person("Guido", "Rau", 0,  "", 0, "");
			ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
			ObjectInputStream in = new ObjectInputStream(socket.getInputStream());			
			out.writeObject(ich);
			out.flush();
			String message = in.readUTF();
			System.out.println(message);
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
