import java.util.ArrayList;
import java.util.List;
import java.util.function.BiPredicate;
import java.util.function.Predicate;

import entities.Person;

interface MyConsumer<T> {
	public void accept(T o);
}

//@FunctionalInterface
interface MyInterface<T> {
	public boolean test(T text);

//	public boolean test2(String text);
}

interface A<T> {
	public boolean test(T text, T text2);

//	public boolean test2(String text);
}

interface B<T> {
	public T test();

//	public boolean test2(String text);
}

public class Start2 {

	static int t(int x) {
		return x + 1;
	}

	public static void main(String[] args) {
//	MyInterface<String>	laengeGroesser10 = (String text) -> {return text.length() > 10;};
//	MyInterface<String>	laengeGroesser10 = (text) -> {return text.length() > 10;};
//	MyInterface<String>	laengeGroesser10 = text -> {return text.length() > 10;};
		MyInterface<String> laengeGroesser10 = text -> text.length() > 10;
//	A<String>	str1LaengerAlsStr2 = (String str1, String str2) -> {return str1.length() > str2.length();};
		BiPredicate<String, String> str1LaengerAlsStr2 = (str1, str2) -> str1.length() > str2.length();
//	B<String> getString = () -> { return "Hallo Welt";};
		B<String> getString = () -> "Hallo Welt";

		pruefen("Hallo schöne Welt", str -> str.contains("x"));
		pruefen("Hallo schöne Welt", str -> str.endsWith("Welt"));

		Person p1 = new Person("Willi", "Wuff", 12, "Musterweg", 10, "München");
		Person p2 = new Person("Donald", "Duck", 34, "Musterweg", 20, "München");
		Person p3 = new Person("Daisy", "Duck", 23, "Musterweg", 30, "München");
		Person p4 = new Person("Willibald", "Igel", 10, "Musterweg", 40, "München");

		List<Person> personen = new ArrayList();
		personen.add(p1);
		personen.add(p2);
		personen.add(p3);
		personen.add(p4);
		for (var pers : personen) {
			pruefen(pers, p -> p.getNachname().equals("Duck"));
		}

		pruefen("Hallo", "Welt", (s1, s2) -> {
			return s1.contains("a") && s2.contains("a");
		});

		int x = 10;

		pruefen("Teststring", s -> {
			double d = 5.6;
			String text = "lksdfnlksdjfdskfl";
			double erg = x * d;
			text += erg;
			return s.length() > 5 && text.length() < 12;
		});

		System.out.println("===================================");

		personen.forEach(p -> System.out.println(p));

		System.out.println("**************************************");

		personen.forEach(System.out::println);

		System.out.println("**************************************");

		personen.forEach(Start2::ausgabe);
		
		
	}

	public static <T> void ausgabe(T o) {
		System.out.println(o);
	}

//	public static void pruefen(String text, MyInterface<String> condition) {
//		boolean erfuellt = condition.test(text);
//		System.out.printf("der Text %s erfüllt die Bedingung %s\n", text, (erfuellt ? "" : "nicht"));
//	}

	public static <T> void pruefen(T p, Predicate<T> condition) {
		boolean erfuellt = condition.test(p);
		System.out.printf("das Prüfobjekt %s erfüllt die Bedingung %s\n", p, (erfuellt ? "" : "nicht"));
	}

	public static <T, U> void pruefen(T p1, U p2, BiPredicate<T, U> condition) {
		boolean erfuellt = condition.test(p1, p2);
		System.out.printf("die Prüfobjekte %s und %s erfüllen die Bedingung %s\n", p1, p2, (erfuellt ? "" : "nicht"));
	}

}
