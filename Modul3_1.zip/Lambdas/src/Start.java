
@FunctionalInterface
interface AB{
	public void test();
	public default void a() {
		 System.out.println("a in Interface A");
	 }
}


@FunctionalInterface
interface MyFunctionalInterface {
	public void test();
	 public default void a() {     // default Methoden seit Java 8
		 System.out.println("a in interface MyFunctionalInterface");
		 privateB();
	 }
	 
	 public static void staticA() {  // static Methoden seit Java 8
		 System.out.println("public static void staticA() in MyFunctionalInterface");
		 staticB();
	 }
	 
	 private void privateB() { // private Methoden seit Java 9
		 System.out.println("private void privateB()");
	 }
	 
	 private static void staticB() {  // static Methoden seit Java 9
		 System.out.println("public static void staticA() in MyFunctionalInterface");
		 
	 }
}



class LambdaTest implements MyFunctionalInterface, AB{

	@Override
	public void test() {
		System.out.println("test() in LambdaTest");
		
	}
	
	public void a() {
		System.out.println("a() in LambdaTest");
		MyFunctionalInterface.super.a();
	}

}

public class Start{
	public static void main(String[] args) {
		LambdaTest lt = new LambdaTest();
		lt.test();
		lt.a();
		MyFunctionalInterface.staticA();
	}
}
