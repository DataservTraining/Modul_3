package eheleute;

import java.util.concurrent.locks.ReentrantLock;

public class Konto {
	public double saldo;
	private ReentrantLock lock = new ReentrantLock();
	
	public Konto(double saldo) {
		super();
		this.saldo = saldo;
	}

	public void showSaldo() {
		System.out.println("Saldo: " + saldo);
	}
	
	public void abheben(double betrag) throws NoMoneyException {
		if(betrag > saldo) {
			throw new NoMoneyException("Konto leer");
		}
		saldo -= betrag;
	}

	public ReentrantLock getLock() {
		return lock;
	}
	
	
}
