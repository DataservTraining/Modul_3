package eheleute;

public class Eheleute2 extends Thread{
	
	private Konto konto;



	public Eheleute2(String name, Konto konto) {
		super(name);
		this.konto = konto;

	}


	@Override
	public void run() {
		while(true) {
			konto.getLock().lock();
				System.out.println(Thread.currentThread().getName() + " will 100 € abheben");
				konto.showSaldo();
				try {
					konto.abheben(100);
				} catch (NoMoneyException e) {
					System.out.println(e.getMessage());
//					if(konto.getLock().isLocked()) {
						konto.getLock().unlock();
//					}
					return;
				}
			konto.getLock().unlock();
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
