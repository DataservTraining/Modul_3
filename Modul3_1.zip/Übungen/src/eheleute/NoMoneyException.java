package eheleute;

public class NoMoneyException extends Exception{
	private static final long serialVersionUID = 1L;

	public NoMoneyException(String arg0) {
		super(arg0);
	}
	
}
