package eheleute;

public class Start {

	public static void main(String[] args) {
		Konto konto = new Konto(4000);
		Eheleute2 eve = new Eheleute2("Eve", konto);
		Eheleute2 bob = new Eheleute2("Bob", konto);
		eve.start();
		bob.start();
		

	}

}
