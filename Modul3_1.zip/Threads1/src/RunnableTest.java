
public class RunnableTest {

	public static void main(String[] args) throws InterruptedException {
		UhrRunnable runnable = new UhrRunnable();
		Thread uhrenThread = new Thread(runnable, "Uhr");
		uhrenThread.setDaemon(true);
		uhrenThread.start();
		
		Thread summiererThread = new Thread(new Runnable() {
			
			@Override
			public void run() {
				int summe = 0;
				for(int z = 1; z < 101; ++z) {
					summe += z;
					try {
						Thread.sleep(50);
					} catch (InterruptedException e) {
			
					}
				}
				
				System.out.println(summe);
			}		
		},
		"");
		
		summiererThread.start();
		
		for(int zaehler = 1; zaehler < 10; ++zaehler) {
			System.out.println("Zähler: " + zaehler);
			Thread.sleep(500);
		}

	}

}
