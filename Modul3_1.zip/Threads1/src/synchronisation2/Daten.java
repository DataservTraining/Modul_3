package synchronisation2;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

public class Daten {
	private int[] data = new int[5];
	private int index;
	private ReentrantLock reentrantLock = new ReentrantLock();
	private Condition condition = reentrantLock.newCondition();
	
	public void write(int wert) {
		System.out.println("in write()");
			reentrantLock.lock();
			while(index == data.length) {
				try {
					condition.await(15, TimeUnit.MILLISECONDS);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			data[index] = wert;
			++index;
			if(index == 1) {
				condition.signalAll();
			}
		reentrantLock.unlock();
	}
	
	public int read() {
		System.out.println("in read()");
		
			while(index == 0) {
				try {
					condition.await(15, TimeUnit.MILLISECONDS);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			int temp = data[0];
			for(int i = 0; i < index-1; ++i) {
				data[i] = data[i+1];
			}
			--index;
			if(index == data.length-1) {
				condition.signalAll();
			}
			return temp;		
		}
	

}
