

public class start {

	public static void main(String[] args) throws InterruptedException {
		System.out.println("Hallo");
		Uhr uhr = new Uhr("Uhr 1");
		Summierer summierer = new Summierer();
		summierer.start();
		uhr.setDaemon(true);
		System.out.println(Thread.MIN_PRIORITY);
		System.out.println(Thread.MAX_PRIORITY);
		uhr.setPriority(1);
//		uhr.setName("Uhr 1");
		uhr.start();
		
		System.out.println(Thread.currentThread().getName());
		
		for(int zaehler = 1; zaehler < 10; ++zaehler) {
			System.out.println("Zähler: " + zaehler);
			Thread.sleep(30);
		}
		System.out.println(uhr.isAlive());
		System.out.println(summierer.isAlive());
		summierer.join();
		System.out.println("Summe: " + summierer.getSumme());

		//uhr.stopThread();
		//uhr.interrupt();
		
	}

}
