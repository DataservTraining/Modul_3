package synchronisation;

public class Reader extends Thread {
	private Daten data;

	public Reader(Daten data) {
		super();
		this.data = data;
	}
	
	public void run() {
		int w; 
		while((w=data.read()) != -1) {
			System.out.println("gelesen: " + w);
			try {
				Thread.sleep(15);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
