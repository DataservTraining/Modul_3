package synchronisation;

public class Daten {
	private int[] data = new int[5];
	private int index;
	private Object monitor1 = new Object();
	private Object monitor2 = new Object();
	
//	public synchronized void write(int wert) {
//		data[index] = wert;
//		++index;
//		
//	}
//	
//	public synchronized int read() {
//		int temp = data[0];
//		for(int i = 0; i < index-1; ++i) {
//			data[i] = data[i+1];
//		}
//		--index;
//		return temp;
//	}

	public void write(int wert) {
		System.out.println("in write()");
		synchronized (monitor1) {
			while(index == data.length) {
				try {
					monitor1.wait();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			data[index] = wert;
			++index;
			if(index == 1) {
				monitor1.notifyAll();
			}
		}
		
	}
	
	public int read() {
		System.out.println("in read()");
		synchronized (monitor1) {
			while(index == 0) {
				try {
					monitor1.wait();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			int temp = data[0];
			for(int i = 0; i < index-1; ++i) {
				data[i] = data[i+1];
			}
			--index;
			if(index == data.length-1) {
				monitor1.notifyAll();
			}
			return temp;		
		}
	}

	
	public void test1() {
		synchronized (monitor2) {
			
		}
	}

	public void test2() {
		synchronized (monitor2) {
			
		}
	}

//	public static synchronized void test() {
//		
//	}

}
