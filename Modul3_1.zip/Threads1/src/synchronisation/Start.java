package synchronisation;

public class Start {

	public static void main(String[] args) {
		Daten daten = new Daten();
		new Writer(daten).start();
		new Reader(daten).start();

	}

}
