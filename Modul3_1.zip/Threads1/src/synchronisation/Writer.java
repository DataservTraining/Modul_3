package synchronisation;

public class Writer extends Thread {
	private Daten data;

	public Writer(Daten data) {
		super();
		this.data = data;
	}
	
	public void run() {
		for(int i = 1; i <101; ++i) {
			data.write(i);
		
			System.out.println("geschrieben: " + i);
			try {
				Thread.sleep(15);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		data.write(-1);
	}

}
