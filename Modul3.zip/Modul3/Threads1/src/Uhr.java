import java.time.LocalTime;

public class Uhr extends Thread{
	private boolean running = true;
	
	public Uhr() {
		
	}

	public Uhr(String name) {
		super(name);
	}


	public void run() {
		while(running) {
			LocalTime time = LocalTime.now();
			System.out.println(Thread.currentThread().getName());
			System.out.println(time);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				return;
			}
		}
	}
	
	public void stopThread() {
		running = false;
	}
}
