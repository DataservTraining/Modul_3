import java.time.LocalTime;

public class UhrRunnable implements Runnable{

private boolean running = true;
	
	public UhrRunnable() {
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public void run() {
		while(running) {
			LocalTime time = LocalTime.now();
			System.out.println(Thread.currentThread().getName());
			System.out.println(time);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				return;
			}
		}
		
	}

}
