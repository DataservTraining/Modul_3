
public class Summierer extends Thread {
	private int summe = 0;
	
	public void run() {
		for(int z = 1; z < 101; ++z) {
			summe += z;
			try {
				Thread.sleep(50);
			} catch (InterruptedException e) {
	
			}
		}
	}
	
	public int getSumme() {return summe;}
}
