package application;

import java.util.Arrays;

public class MyArrayList <T>{
	private T[] data;
	private int index;
	
	@SuppressWarnings("unchecked")
	public MyArrayList() {
		data = (T[]) new Object[10];
	}
	
	public void add(T o) {
		if(index == data.length) resize();
		data[index++] = o;
	}
	
	public T get(int ind) {
		if (ind < 0 || ind >= data.length) throw new IllegalArgumentException("Index ungültig");
		return data[ind];
	}

	private void resize() {
		data = Arrays.copyOf(data, index * 2);
		
	}

}
