package application;

public class Animal {
	public void geimpft() {
		System.out.println("geimpft!");
	}
}
