
import java.util.*;



public class MapTest {

	public static void main(String[] args) {
		var x = 7.8;
		Person p1 = new Person("Willi", "Wuff", 12);
		Person p2 = new Person("Donald", "Duck", 34);
		Person p3 = new Person("Daisy", "Duck", 23);
		Person p4 = new Person("Willibald", "Igel", 10);
		
		Map<Integer, String> integer = new HashMap<>();
		integer.put(1, "eins");
		integer.put(2, "zwei");
		integer.put(3, "drei");
		
		for(int index = 1; index <= integer.size(); ++ index) {
			System.out.println("Key: " + index +"\tValue: " + integer.get(index));
		}
		
		Set<Integer> keys = integer.keySet();
		for(Integer i : keys) {
			System.out.println("Key: " + i +"\tValue: " + integer.get(i));
		}
		
//		Set<Map.Entry<Integer, String>> entries = integer.entrySet();
		var entries = integer.entrySet();
		
		for(Map.Entry<Integer, String> entry : entries) {
//			for(var entry : entries) {
			System.out.println("Key: " + entry.getKey() +"\tValue: " + entry.getValue());
		}
		
		Map<String, Person> personen = new TreeMap<>();
		
		personen.put("Willi.Wuff@t-online.de", p1);
		personen.put("Donald.Duck@t-online.de", p2);
		personen.put("Daisy.Duck@t-online.de", p3);
		personen.put("Willibald.Igel@t-online.de", p4);
		personen.put("Willi.Wuff@gmx.net", p1);
		personen.put("Donald.Duck@yahoo.de", p2);
		
		for(Map.Entry<String, Person> p : personen.entrySet()) {
			System.out.println("Key: " + p.getKey() +"\tValue: " + p.getValue());
		}

	}

}
