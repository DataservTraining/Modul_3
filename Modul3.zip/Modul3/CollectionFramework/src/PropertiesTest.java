import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

public class PropertiesTest {

	public static void main(String[] args) {
		Map<Object, Object> map;
		Properties props = new Properties();
		props.put(45, "value1");
		props.put("key2", 23);

		
		try {
			props.store(new FileWriter("properties.ini"), "Kommentar");
			props.storeToXML(new FileOutputStream("properties.xml"), "Kommentar");
			
			Properties props2 = new Properties();
			props2.load(new FileReader("properties.ini"));
			System.out.println(props2.get("key1"));
			System.out.println(props2.get("key2"));
			
			Properties props3 = new Properties();
			props3.loadFromXML(new FileInputStream("properties.xml"));
			System.out.println(props3.get("key1"));
			System.out.println(props3.get("key2"));
			
			Set<Entry<Object, Object>> entries = props3.entrySet();
			for(Entry<Object, Object> entry : entries) {
				System.out.println(entry.getKey() + ": " + entry.getValue());
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
