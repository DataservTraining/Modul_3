package application;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;



public class IntArray {
	int[] feld = new int[5];
	int index = 0;
	ReentrantLock lock = new ReentrantLock();
	Condition condition = lock.newCondition();
	
	public void write(int wert) {
		lock.lock();
		while(index == feld.length) {
			try {
				condition.await();
			} catch (InterruptedException e) {
			}
		}
		feld[index] = wert;
		++index;
		
		if(index == 1) {
			condition.signalAll();
		}
		
		lock.unlock();
	}
	
	public int read() {
		lock.lock();
		while(index == 0) {
			try {
				System.out.println("await in read: ");
				condition.await();
			} catch (InterruptedException e) {
			}
		}
		
		int temp = feld[0];
		for(int i = 0; i < index-1; ++i) {
			feld[i] = feld[i+1];
		}
		--index;
		
		if(index == feld.length) {
			condition.signalAll();
		}
		lock.unlock();
		return temp;
	}

}
