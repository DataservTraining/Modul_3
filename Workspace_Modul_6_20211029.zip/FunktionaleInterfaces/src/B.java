@FunctionalInterface
public interface B {
	double mult(double x);
}
