
public interface D<E> {
	void a (E x);
}
