
public class Test implements MyFunctionalInterface, A{

	
	
	@Override
	public int add(int a, int b) {
		
		return a + b;
	}

	@Override
	public double test() {
		
		return A.super.test();
	}

	@Override
	public void xyz() {
		// TODO Auto-generated method stub
		
	}

}
