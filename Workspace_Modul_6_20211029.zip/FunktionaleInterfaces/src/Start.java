public class Start {

	public static void main(String[] args) {
		Test t = new Test();
		System.out.println(t.add(4, 7));
		t.test();
		MyFunctionalInterface.xyz();
		
//		()->{};     // typ x(){}

		A l = () -> {};  // A l = A.xyz();
		
		MyFunctionalInterface mfi = (int x, int y) -> {
														System.out.println(x + y);  
														return  x + y;
													  };
		MyFunctionalInterface mfi2 = (x, y) -> {return  x + y;};
		MyFunctionalInterface mfi3 = (x, y) -> x + y;
		
		B b = (double v) -> {return v*2;};
		B b2 = (v) -> {return v*2;};
		B b3 = (v) -> v*2;
		B b4 = v -> v*2;
		
		C c = () -> System.out.println(10); 
		
		D<String> d = (String str) -> {System.out.println(str);};
		D<String> d3 = (str) -> {System.out.println(str);};
		D<Integer> d2 = str -> System.out.println(str);
	}

}
