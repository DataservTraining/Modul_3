import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class LambdaTest1 {

	public static void main(String[] args) {
		List<Integer> integerList = new ArrayList<>();

		for (int i = 0; i < 20; ++i) {
			integerList.add((int) (Math.random() * 100 + 1));
		}

		for (int x : integerList) {
			System.out.print(x + ", ");
		}
		System.out.println();
		
//		integerList.sort(new Comparator<Integer>() {
//
//			@Override
//			public int compare(Integer o1, Integer o2) {		
//				return o1.compareTo(o2);
//			}
//			
//		});
		
//		integerList.sort((x, y) -> x.compareTo(y));
		integerList.sort(Integer::compareTo);
		
		integerList.forEach(i -> System.out.print(i + ", "));
//		integerList.forEach(System.out::println);
		
//		for (int x : integerList) {
//			System.out.print(x + ", ");
//		}

	}

}
