
public interface C {
	void x();
}
