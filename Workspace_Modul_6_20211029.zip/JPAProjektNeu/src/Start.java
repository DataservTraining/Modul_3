

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import model.Person;


public class Start {

	public static void main(String[] args) {
		
		// ich habe einige Probleme gel�st bekommen, aber leider sind daf�r andere 
		// wieder aufgetreten.
		// Um Entities von einer Tabelle zu erzeugen, wird doch die Einstellung MYSQL bei 
		// Erstellen der Datanbankverbindung ben�tigt. Der generische Treiber unterts�tzt
		// das leider nicht. Aber man genau darauf achten, dass in allen Dialogen der richtige
		// Treiber angegeben wird. Danach kann man dann zwar deie Entity-Klasse erzeugen lassen,
		// beim Start des Programms kommt es aber dennoch zu einer Runtime-Exception
		// Exception in thread "main" java.lang.IllegalArgumentException: 
		//          Object: model.Person@49d904ec is not a known Entity type.
		// Hierf�r habe ich aber im Internet noch keine L�sung gefunden. Das Problem wird zwar
		// auf vielen Seiten diskutiert, aber wirklich hilfreiche Informationen habe ich bisher
		// keine gefunden. Aber ich werde weiter suchen.
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPAProjektNeu");
		EntityManager em = emf.createEntityManager();
		System.out.println(em.isOpen());
		Person p = new Person();
		p.setId(1);
		p.setName("test");
		System.out.println(p);
		em.getTransaction().begin();
		em.persist(p);
		em.getTransaction().commit();
		em.close();
		emf.close();

	}

}
