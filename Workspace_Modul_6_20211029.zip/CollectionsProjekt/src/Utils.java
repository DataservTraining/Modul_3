import java.util.ArrayList;
import java.util.List;

public class Utils {
	public static List<Person> createPersonen(int i) {
		List<Person> personen = new ArrayList<>();
		for(int z = 0; z < i; ++z) {
			personen.add(new Person("Name " + (int) (Math.random() * 60 + 1),
									(int) (Math.random() * 100 + 1),
									(Math.random() * 3000 + 1)));
		}

		return personen;
	}

	public static List<Person> createPersonenGeordnet(int i) {
		List<Person> personen = new ArrayList<>();
		for(int z = 0; z < i; ++z) {
			personen.add(new Person("Name " + (z+1),
									(int) (Math.random() * 100 + 1),
									(Math.random() * 3000 + 1)));
		}

		return personen;
	}
	
	
}
