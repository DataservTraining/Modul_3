import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class SetTest {

	public static void main(String[] args) {
		einfacherSetTest();
		System.out.println("\n=====================================\n");
		
		personenTest();
		
	}
	
	private static void personenTest() {
		List<Person> personen = createPersonen();
		Set<Person> personenSet = new TreeSet<>(new Comparator<Person>() {

			@Override
			public int compare(Person o1, Person o2) {
				
//				return o1.getAlter() - o2.getAlter();
				long erg = (Double.doubleToLongBits(o1.getGehalt()) -  Double.doubleToLongBits(o2.getGehalt()));
				
				return erg < 0 ? -1 : erg > 0 ? 1 : 0 ;
			}
		});
		
		personenSet.addAll(personen);
		
		for(Person p : personenSet) {
			System.out.println(p);
		}
		
		System.out.println("Gr��e des Sets: " + personenSet.size());
		
	}

	private static void einfacherSetTest() {
		Set<Integer> integerList = new TreeSet<>();

		while(integerList.size() < 20) {
			int wert = (int) (Math.random() * 100 + 1);
			System.out.print(wert + ", ");
			boolean ok = integerList.add(wert);
			if(!ok) {
//				System.out.println(wert + " ist doppelt");
			}
		}
		
		System.out.println();

		for (int x : integerList) {
			System.out.print(x + ", ");
		}

//		System.out.println("Wert 42" + integerList.);
		
		integerList.remove(10);
		
		System.out.println();
		
		
		for (int x : integerList) {
			System.out.print(x + ", ");
		}
		
		System.out.println();
	}

	private static List<Person> createPersonen() {
		List<Person> personen = new ArrayList<>();
		for(int z = 0; z < 20; ++z) {
			personen.add(new Person("Name " + (int) (Math.random() * 60 + 1),
									(int) (Math.random() * 100 + 1),
									(Math.random() * 3000 + 1)));
		}
		System.out.println(personen);
		return personen;
	}
}
