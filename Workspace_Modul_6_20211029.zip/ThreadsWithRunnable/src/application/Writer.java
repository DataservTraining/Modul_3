package application;

public class Writer implements Runnable {
	private IntArray array;

	public Writer(IntArray array) {
		super();
		this.array = array;
	}

	@Override
	public void run() {
		for (int zahl = 1; zahl < 101; ++zahl) {
				array.write(zahl);
				System.out.println(zahl + " geschrieben");
			try {
				Thread.sleep(15);
			} catch (InterruptedException e) {
			}
		}
		array.write(-1);
	}

}
