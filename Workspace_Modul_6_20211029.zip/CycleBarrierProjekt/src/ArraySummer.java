import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.CyclicBarrier;

public class ArraySummer {

	public static void main(String[] args) {
		int[] array = new int[1000];
		Random r = new Random();
		for (int i = 0; i < array.length; i++)
			array[i] = Math.abs(r.nextInt() / 2);
		parallSummer(array);
	}

	public static void parallSummer(int[] array) {
		int prozessors = 2; // Runtime.getRuntime().availableProcessors();
		final List<Long> longs = new ArrayList<Long>();
		Runnable merger = new Runnable() {

			@Override
			public void run() {
				long sum = 0;
				for (long i : longs)
					sum += i;
				System.out.println(sum);
			}
		};

		CyclicBarrier barrier = new CyclicBarrier(prozessors, merger);

		for (int part = 0; part < prozessors; part++)
			new Thread(new AtomarSummer(barrier, array, prozessors, part, longs)).start();
	}

}