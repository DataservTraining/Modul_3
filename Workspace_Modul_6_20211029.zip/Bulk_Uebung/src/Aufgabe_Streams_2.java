import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Aufgabe_Streams_2 {

	public static void main(String[] args) {
		final String[] namesArray = { "Tim", "Tom", "Andy", "Mike", "Merten" };
		final List<String> names = Arrays.asList(namesArray);
		final Stream<String> streamFromArray = Arrays.stream(namesArray);
		final Stream<String> streamFromList = names.stream();
		final Stream<String> streamFromValues = Stream.of("Tim", "Tom", "Andy", "Mike", "Merten" );
		
		
		final Object[] contentsAsArray =  streamFromArray.toArray();
		final List<String> contentsAsList = streamFromValues.collect(Collectors.toCollection(ArrayList::new));
		for(var o : contentsAsArray) System.out.println(o);
		contentsAsList.forEach(str -> System.out.print(str + ", "));
		System.out.println();

	}

}
