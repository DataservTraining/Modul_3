import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.function.Predicate;

public class Aufgabe_5 {

	public static void main(String[] args) {
		// 5a
		final Predicate<String> isShortWord = str -> str.length() < 4;
		final List<String> names = createNamesList();
		names.removeIf(isShortWord);
		names.forEach(str -> System.out.print(str + ", "));
		System.out.println();
		// 5b
		removeIf_External_Iteration(isShortWord).forEach(str -> System.out.print(str + ", "));
		System.out.println();
		removeIf_External_Iteration(str -> str.length() > 4).forEach(str -> System.out.print(str + ", "));
		System.out.println();
		removeIf_External_Iteration(str -> str.startsWith("T")).forEach(str -> System.out.print(str + ", "));
		System.out.println();
	}

	// 5b
	private static List<String> removeIf_External_Iteration(Predicate<String> condition) {
		final List<String> names = createNamesList();
		final Iterator<String> it = names.iterator();
		while (it.hasNext()) {
			final String currentName = it.next();
			if (condition.test(currentName)) {
				it.remove();
			}
		}
		return names;
	}

	private static List<String> createNamesList() {
		final List<String> names = new ArrayList<>();
		names.add("Michael");
		names.add("Tim");
		names.add("Flo");
		names.add("Clemens");
		return names;
	}

}
