import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class Aufgabe_Streams_1 {

	public static void main(String[] args) {
		// 1a
		// Create intermediate terminal
		
		// 1b create
		final String[] namesArray = { "Tim", "Tom", "Andy", "Mike", "Merten" };
		final List<String> names = Arrays.asList(namesArray);
		final Stream<String> streamFromArray = Arrays.stream(namesArray);
		final Stream<String> streamFromList = names.stream();
		final Stream<String> streamFromValues = Stream.of("Tim", "Tom", "Andy", "Mike", "Merten" );
		
		// 1c intermediate
		
		final Stream<String> filtered = names.stream().filter(str -> str.startsWith("T"));
		final Stream<String> mapped = names.stream().map(str -> str.toUpperCase());
		
		// 1d terminal
		filtered.forEach(str -> System.out.print(str + ", "));
		System.out.println();
		mapped.forEach(str -> System.out.print(str + ", "));
		System.out.println();
			
	}

}
