import java.util.ArrayList;
import java.util.List;

public class Aufgabe_6 {

	public static void main(String[] args) {
	
		List<String> namen = createNamesList();
		namen.replaceAll(str -> str.startsWith("M") ? ">>" + str.toUpperCase() + "<<" : str);
		namen.forEach(str -> System.out.print(str + ", "));
		System.out.println();

	}
	
	private static List<String> createNamesList() {
		final List<String> names = new ArrayList<>();
		names.add("Michael");
		names.add("Tim");
		names.add("Flo");
		names.add("Clemens");
		return names;
	}

}
