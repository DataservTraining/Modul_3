import java.util.Arrays;
import java.util.List;

public class Aufgabe_1 {

	public static void main(String[] args) {
		final List<String> names = Arrays.asList("Tim", "Peter", "Mike");
		names.forEach(System.out::println);
		

	}

}
