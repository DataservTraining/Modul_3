import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Aufgabe_Streams_4 {

	public static void main(String[] args) {
		// 4a
		final Stream<String> inputs = Stream.of("Tim", "Tom", "Andy", "Mike", "Merten");
		final Map<Character, List<String>> grouped = inputs.collect(Collectors.groupingBy(str -> str.charAt(0)));
		System.out.println(grouped);
		
		// 4b
		final Stream<String> inputs2 = Stream.of("Tim", "Tom", "Andy", "Mike", "Merten");
		final Map<Boolean, List<String>> partioned = inputs2.collect(Collectors.partitioningBy(str -> str.length() < 4));
		System.out.println(partioned);
		
		// 4c
		final Stream<String> inputs3 = Stream.of("Tim", "Tom", "Andy", "Mike", "Merten");
		final Map<Character, Long> groupedAndCounted = inputs3.collect(Collectors.groupingBy(str->str.charAt(0), Collectors.counting()));
		System.out.println(groupedAndCounted);
		
	}

}
