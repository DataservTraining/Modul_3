import java.util.function.Predicate;

public class Aufgabe_3 {

	public static void main(String[] args) {
		final Predicate<Person> isOlderThan18 = p -> p.getAge() >= 18;
		final Predicate<Person> isAdult = Person::isAdult;
		
		
	}

}
