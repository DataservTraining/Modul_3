import java.util.function.IntPredicate;
import java.util.function.Predicate;

public class Aufgabe_2 {

	public static void main(String[] args) {
		// 2a
		final Predicate<Integer> isEven = z -> z % 2 == 0;
		final Predicate<Integer> isNull = z -> z == 0;
//		final IntPredicate isPositive = z -> z > 0;
		final Predicate<Integer> isPositive = z -> z > 0;
		// 2b
		final Predicate<String> isShortWord = str ->str.length() < 4;
		// 2c
		final Predicate<Integer> isPositiveAndEven = isEven.and(z -> z > 0);
		final Predicate<Integer> isPositiveAndEven2 = isEven.and(isPositive);
		final Predicate<Integer> isPositiveAndOdd = isPositive.and(z -> z%2==1);
	}

}
