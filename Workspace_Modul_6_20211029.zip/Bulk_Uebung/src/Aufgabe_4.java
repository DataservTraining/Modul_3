import java.util.Arrays;
import java.util.List;

public class Aufgabe_4 {

	public static void main(String[] args) {
		final List<String> names = Arrays.asList("Tim", "Peter", "Mike", "Andy");
		final List<String> names2 = Arrays.asList("Tim", "Peter", "Mike", "Andy");
		
//		names.sort((str1, str2) -> str1.compareTo(str2));
		names.sort(String::compareTo);
		names.forEach(str -> System.out.print(str + ", "));
		System.out.println();
		names2.stream().sorted().forEach(str -> System.out.print(str + ", "));

	}

}
