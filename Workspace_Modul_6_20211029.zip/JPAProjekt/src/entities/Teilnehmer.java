package entities;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the teilnehmer database table.
 * 
 */
@Entity
@Table(name="teilnehmer")
@NamedQuery(name="Teilnehmer.findAll", query="SELECT t FROM Teilnehmer t")
public class Teilnehmer implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true, nullable=false)
	private int idteilnehmer;

	@Column(length=45)
	private String name;

	@Column(length=45)
	private String vorname;

	//bi-directional many-to-one association to Seminar
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="kurs")
	private Seminar seminar;

	public Teilnehmer() {
	}
	
	public Teilnehmer(String name, String vorname) {
		super();
		this.name = name;
		this.vorname = vorname;
	}

	public Teilnehmer(String name, String vorname, Seminar seminar) {
		super();
		this.name = name;
		this.vorname = vorname;
		this.seminar = seminar;
	}



	public int getIdteilnehmer() {
		return this.idteilnehmer;
	}

	public void setIdteilnehmer(int idteilnehmer) {
		this.idteilnehmer = idteilnehmer;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getVorname() {
		return this.vorname;
	}

	public void setVorname(String vorname) {
		this.vorname = vorname;
	}

	public Seminar getSeminar() {
		return this.seminar;
	}

	public void setSeminar(Seminar seminar) {
		this.seminar = seminar;
	}



	@Override
	public String toString() {
		return "Teilnehmer [idteilnehmer=" + idteilnehmer + ", name=" + name + ", vorname=" + vorname + ", seminar="
				+ (seminar != null ? seminar.getThema(): "kein Seminar") + "]";
	}

	
}