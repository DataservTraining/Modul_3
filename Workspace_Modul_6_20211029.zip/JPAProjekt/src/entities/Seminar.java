package entities;

import java.io.Serializable;
import javax.persistence.*;

import java.util.ArrayList;
import java.util.List;


/**
 * The persistent class for the seminar database table.
 * 
 */
@Entity
@Table(name="seminar")
@NamedQuery(name="Seminar.findAll", query="SELECT s FROM Seminar s")
public class Seminar implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true, nullable=false)
	private int idseminar;

	@Column(length=45)
	private String thema;

	//bi-directional many-to-one association to Teilnehmer
	@OneToMany(mappedBy="seminar", cascade=CascadeType.ALL)
	private List<Teilnehmer> teilnehmers;

	public Seminar() {
	}
	
	

	public Seminar(String thema, List<Teilnehmer> teilnehmers) {
		super();
		this.thema = thema;
		this.teilnehmers = teilnehmers;
	}



	public Seminar(String thema) {
		this.thema = thema;
	}



	public int getIdseminar() {
		return this.idseminar;
	}

	public void setIdseminar(int idseminar) {
		this.idseminar = idseminar;
	}

	public String getThema() {
		return this.thema;
	}

	public void setThema(String thema) {
		this.thema = thema;
	}

	
	public List<Teilnehmer> getTeilnehmers() {
		return this.teilnehmers;
	}

	public void setTeilnehmers(List<Teilnehmer> teilnehmers) {
		this.teilnehmers = teilnehmers;
	}

	public Teilnehmer addTeilnehmer(Teilnehmer teilnehmer) {
		if(teilnehmers == null) teilnehmers = new ArrayList<Teilnehmer>();
		getTeilnehmers().add(teilnehmer);
		teilnehmer.setSeminar(this);

		return teilnehmer;
	}

	public Teilnehmer removeTeilnehmer(Teilnehmer teilnehmer) {
		if(teilnehmers == null) return null;
		getTeilnehmers().remove(teilnehmer);
		teilnehmer.setSeminar(null);

		return teilnehmer;
	}



	@Override
	public String toString() {
		return "Seminar [idseminar=" + idseminar + ", thema=" + thema 
				+ ", teilnehmers=" + ((teilnehmers != null && !teilnehmers.isEmpty())? teilnehmers : "keine Teilnehmer")+ "]";
	}
	
	

}