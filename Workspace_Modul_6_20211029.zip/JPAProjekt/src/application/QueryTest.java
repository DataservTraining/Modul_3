package application;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import entities.Person;

public class QueryTest {

	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPAProjekt");
		EntityManager em = emf.createEntityManager();

//		TypedQuery<Person> query = em.createQuery("select a from Person a where a.id > ?1", Person.class);
//		TypedQuery<Person> query = em.createQuery("select a from Person a where a.id > :id", Person.class);
//		query.setParameter(1, 20);
//		query.setParameter("id", 18);
		
//		TypedQuery<Person> query = em.createNamedQuery("Person.findAll", Person.class);
		TypedQuery<Person> query = em.createNamedQuery("Person.findById", Person.class);
		query.setParameter("id", 10);
		List<Person> personen = query.getResultList();
		
		for(Person p : personen) {
			System.out.println(p);
		}
		
//		TypedQuery<String> query2 = em.createQuery("select a.name from Person a", String.class);
		Query query2 = em.createQuery("select a.id, a.name from Person a");
		
		@SuppressWarnings("unchecked")
		List<Object[]> liste = query2.getResultList();
		
		for(Object[] ol : liste) {
			for(Object o: ol ) {
				System.out.printf("%s    ", o);
			}
			System.out.println();
		}
		
//		List<String> namen = query2.getResultList();
//		
//		for(String s : namen) {
//			System.out.println(s);
//		}
		
//		Query query3 = em.createQuery("select t, s from Teilnehmer t left join t.seminar s ");
		Query query3 = em.createQuery("select t, s from Seminar s left join s.teilnehmers t ");
//		Query query3 = em.createQuery("select t, s from Teilnehmer t inner join Seminar s on t.seminar.idseminar=s.idseminar");
		
		liste = query3.getResultList();
		for(Object[] ol : liste) {
			for(Object o: ol ) {
				System.out.printf("%s    ", o);
			}
			System.out.println();
		}
		
		Query query4 = em.createQuery("update Person p set p.name='Rau' where p.id=28");
		em.getTransaction().begin();
		query4.executeUpdate();
		em.getTransaction().commit();
		
		em.close();
		emf.close();
	}

}
