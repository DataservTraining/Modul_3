package application;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.LockModeType;
import javax.persistence.Persistence;

import entities.Person;
import entities.Seminar;
import entities.Teilnehmer;

public class JPATest {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPAProjekt");
		EntityManager em = emf.createEntityManager();
		Person person1 = new Person("Guido", "Rau");
//		System.out.println(person1);
//		em.getTransaction().begin();
//		em.persist(person1);
//		em.getTransaction().commit();
//		person1 = em.find(Person.class, 28);
//		em.getTransaction().begin();
//		em.lock(person1, LockModeType.PESSIMISTIC_READ);
//		
//		Person person2 = em.find(Person.class, 28);
//		if(person1.equals(person2) ) {
//			throw new NullPointerException();
//		}
//		em.getTransaction().commit();
//		System.out.println(person2);
//		System.out.println(person1);
		
		
		Seminar seminar = new Seminar("ITIL");
		for(int i = 1; i < 5; i++) {
			seminar.addTeilnehmer(new Teilnehmer("Vorname von Teilnehmer " + i, 
													"Name von Teilnehmer " + i));
		}
		
//		em.getTransaction().begin();
//		em.persist(seminar);
//		em.getTransaction().commit();
		
		Teilnehmer tn = em.find(Teilnehmer.class, 7);
		
		System.out.println(tn);
		
		
		em.close();
		emf.close();
	}

}
