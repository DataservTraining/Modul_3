package application;

public class Start {

	public static void main(String[] args) {
		IntArray array = new IntArray();
		Writer writer = new Writer(array);
		Reader reader = new Reader(array);
		writer.start();
		reader.start();

	}

}
