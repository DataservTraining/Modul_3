import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class ObjektServer {

	public static void main(String[] args) {
		ObjectInputStream reader = null;
		ObjectOutputStream writer = null;
		Socket socket = null;
		ServerSocket server = null;
		try {
			server = new ServerSocket(10000);
			System.out.println("Server gestartet");
			socket = server.accept();
			writer = new ObjectOutputStream(socket.getOutputStream());
			reader = new ObjectInputStream(socket.getInputStream());
			
			Person pers = (Person) reader.readObject();
			pers.setName("ge�ndert");
			writer.writeObject(pers);
			writer.flush();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {
				socket.close();
				server.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}


	}

}
