import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {

	public static void main(String[] args) {
		BufferedReader reader = null;
		PrintWriter writer = null;
		Socket socket = null;
		ServerSocket server = null;
		try {
			server = new ServerSocket(10000);
			System.out.println("Server gestartet");
			socket = server.accept();
			reader = new BufferedReader( new InputStreamReader(socket.getInputStream()));
			writer = new PrintWriter( new OutputStreamWriter(socket.getOutputStream()));
			String message = reader.readLine();
			System.out.println(message);
			writer.println("Danke f�r die Gr��e");
			writer.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				socket.close();
				server.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

}
