package database;

public enum Gender {
MALE, FEMALE
}
