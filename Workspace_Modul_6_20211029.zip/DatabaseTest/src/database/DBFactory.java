package database;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.InvalidPropertiesFormatException;
import java.util.Properties;

public class DBFactory {
	private static CoronaDBInterface dbInterface = null;
	private static String eingabePDF = null;
	private static String database = null;
	private static String dbDriver = null;
	private static String dbUrl = null;
	private static String host = null;
	
	private DBFactory() {
		
	}
	
	public static CoronaDBInterface getInstance() {
		if(dbInterface == null) {
			Properties props = new Properties();
			try {
				props.loadFromXML(new FileInputStream("properties.xml"));
				host = props.getProperty("host");
				dbDriver = props.getProperty("DBDriver");
				database = props.getProperty("Database");
				dbUrl = props.getProperty("URL");
				
			} catch (IOException e) {
				e.printStackTrace();
			} catch (SecurityException e) {
				e.printStackTrace();
			} 
		}
		
		return dbInterface;
	}
	
	public static String getEingabePDF() {
		if(eingabePDF == null) {
			Properties props = new Properties();
			try {
				props.loadFromXML(new FileInputStream("properties.xml"));
				eingabePDF = props.getProperty("eingabePDF");
			} catch (InvalidPropertiesFormatException e) {
				e.printStackTrace();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
			
		}
		return eingabePDF;
	}
	
	public static String getDriver() {
		return dbDriver;
	}
	
	public static String getURL() {
		return dbUrl;
	}
	
	public static String getDatabase() {
		return database;
	}

	public static String getHost() {
		return host;
	}
}
