package database;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;

public class Start {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		CoronaDBInterface db = DBFactory.getInstance();
//		<entry key="Database">SeminarDozent</entry>
//		<entry key="URL">jdbc:mysql://192.168.56.99:3306/</entry>
		
//		Class.forName("org.mariadb.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://192.168.56.99:3306/Teilnehmer2", "Dozent", "dozent");
		DatabaseMetaData metaDatabase = con.getMetaData();
		
		Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
		stmt.executeUpdate("create database if not exists Teilnehmer2;");
		stmt.executeUpdate("drop table person1;");
		String sql1 = """
					create table if not exists person1 (
						id integer primary key auto_increment,
						vorname varchar(20),
						nachname varchar(20),
						geburtstag date
					);
				""";
		final int ID = 1;
		final int VORNAME = 2;
		final int NACHNAME = 3;
		final int GEBURTSDATUM = 4;
		
		con.setAutoCommit(false);
		stmt.executeUpdate(sql1);
		
		String sql2 = """
				insert into person1 (vorname, nachname, geburtstag) values (?, ?, ?);
				""";
		
		PreparedStatement pstm = con.prepareStatement(sql2);
		
		for(int i = 1; i < 20; ++i) {
			pstm.setString(1, "vorname " + i);
			pstm.setString(2, "nachname " + i);
			pstm.setDate(3, Date.valueOf(LocalDate.now()));  // Date.toLocalDate()
			pstm.executeUpdate();
		}
		
		con.commit();
		
		con.setAutoCommit(true);
		
		
		ResultSet rs = stmt.executeQuery("select * from person1");
		ResultSetMetaData metaData = rs.getMetaData();
		
		int anzahlSpalten = metaData.getColumnCount();
		rs.last();
		int anzahlDatensaetze = rs.getRow();
		rs.beforeFirst();
		
		System.out.printf("ResultSet mit %d Spalten und %d Datens�tzen.", anzahlSpalten, anzahlDatensaetze);
		
		
		System.out.println();
		System.out.println(metaData.getColumnLabel(ID) + "\t" + 
						   metaData.getColumnLabel(VORNAME) + "\t\t" +
						   metaData.getColumnLabel(NACHNAME) + "\t" +
						   metaData.getColumnLabel(GEBURTSDATUM) );
		System.out.println();
		while(rs.next()) {
			int id = rs.getInt(ID);
			String vorname = rs.getString(VORNAME);
			String nachname = rs.getString(NACHNAME);
			Date geburtsdatum = rs.getDate(GEBURTSDATUM);
			System.out.println(id + "\t" + vorname + "\t" + nachname + "\t" + geburtsdatum );
			
			Person p = new Person(id, vorname + " " + nachname, geburtsdatum.toLocalDate());
//			System.out.println(p);
		}
		
		rs.absolute(2);
//		rs.deleteRow();
//		rs.updateRow();
//		
//		rs.moveToInsertRow();
//		rs.updateString(VORNAME, "neuer Vorname");
//		rs.updateString(NACHNAME, "neuer Nachname");
//		rs.updateDate(GEBURTSDATUM, Date.valueOf(LocalDate.of(1980, 5, 3)));
//		rs.insertRow();
//		
		
		
		
//		ResultSet rs = stmt.executeQuery("select * from menagerie.pet");
//		
//		while (rs.next()) {
//			System.out.println(rs.getString("name") + "    "   + rs.getString("owner") + "   " +
//								rs.getString("species") + "   "  + rs.getString("sex") +  "   " + 
//								rs.getString("birth") + "    " + rs.getString("death"));
//		}
		
		
		con.close();
		

	}

}
