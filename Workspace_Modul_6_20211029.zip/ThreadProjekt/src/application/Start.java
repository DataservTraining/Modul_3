package application;

public class Start {

	public static void main(String[] args) {
		UhrenThread uhr1 = new UhrenThread();
		uhr1.setDaemon(true);
		uhr1.setName("Uhr 1");
		uhr1.setPriority(2);
		uhr1.start();
		
		for(int i = 1; i < 10; ++i) {
			System.out.println("Z�hler: " + i);
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
			}
		}
		
//		uhr1.stop();
//		uhr1.interrupt();
//		uhr1.stoppRunning();
		
	}

}
