package application;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class UhrenThread extends Thread{
	private boolean running = true;
	
	public void run() {
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss.SS");
		
		while (running) {
			System.out.println(Thread.currentThread().getName() + ": " + formatter.format(LocalTime.now()));
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				return;
			}
		}
		
	}

	public boolean isRunning() {
		return running;
	}

	public void stoppRunning() {
		this.running = false;
	}
	
	

}
