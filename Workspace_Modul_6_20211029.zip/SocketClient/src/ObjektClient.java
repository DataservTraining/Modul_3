import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

public class ObjektClient {

	public static void main(String[] args) {
		ObjectInputStream reader = null;
		ObjectOutputStream writer = null;
		Socket socket = null;
		try {
			socket = new Socket(InetAddress.getLocalHost(), 10000 );
			
			writer = new ObjectOutputStream(socket.getOutputStream());
			writer.writeObject(new Person("Willi Wuff", 17, 12313.34));
			writer.flush();
			
			InputStream in = socket.getInputStream();
			reader = new ObjectInputStream((InputStream)in);
			Person antwort = (Person) reader.readObject();
			System.out.println(antwort);
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}finally {
			try {
				socket.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

}
